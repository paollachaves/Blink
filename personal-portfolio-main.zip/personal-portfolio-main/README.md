# Portfolio Website

## Setup

1. Add SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SENDER_EMAIL, CONTACT_EMAIL, NEXT_PUBLIC_CONTACT_EMAIL environment variable in .env.local
2. That's it!

# Tech stack

- React & Next.js (v14.2.5) (App Router & Server Actions)
- TypeScript
- Tailwind CSS
- Framer Motion
- React Email & nodemailer
- Vercel hosting.
